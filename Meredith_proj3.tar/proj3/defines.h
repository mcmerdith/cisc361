#ifndef _DEFINES
#define _DEFINES

#define PROMPTMAX 64
#define MAXARGS 16
#define MAXLINE 128

#endif