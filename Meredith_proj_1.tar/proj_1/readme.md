# CISC361 Programming Assignment 1

### Matthew Meredith

## Building

```make all```

#### My Code

My code can be built with

```make mp3```

#### ChatGPT

Just for fun, I gave the prompt to ChatGPT (after I finished my assignment).

ChatGPTs attempt can be built with

```make chatgpt```
